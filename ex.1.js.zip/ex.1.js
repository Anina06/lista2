/* um programa no qual o usuário digite dois números e mostre na tela a multiplicação desses números */

var numero1
var numero2


numero1 = Number(prompt('Digite o primeiro número'))
numero2 = Number(prompt('Digite o segundo número'))

let resultado = numero1 * numero2;

alert('O resultado da multiplicação:' + resultado)

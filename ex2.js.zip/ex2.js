/*2) Desenvolva uma programação que peça ao usuário para digitar o ano do seu nascimento no formato (YYYY) e o ano atual também no formato (YYYY). Em seguida mostre na tela qual a idade do usuário em anos, em meses, em dias e em semanas. */



var anonasc
var anoatual
var idade
var meses
var semanas
var dias


anonasc = Number(prompt('Digite o ano de seu nascimento'));
anoatual = Number(prompt('Digite o ano atual'))


idade = anoatual - anonasc;


meses = idade * 12;


semanas = idade * 52;


dias = idade * 365;


alert('Aqui estão os dias que você conseguiu sobreviver do apocalipse zumbi!:' +'idade=' + idade + ','+ 'meses=' + meses + ',' +'semanas=' + semanas + ',' + 'dias=' + dias)



